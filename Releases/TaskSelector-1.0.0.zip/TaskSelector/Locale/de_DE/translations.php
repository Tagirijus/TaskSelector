<?php

return array(
    'This plugin adds a task selector next to the board selector.' => 'Dieses Plugin fügt einen Aufgaben-Selektor neben dem Projekt-Selektor hinzu.',
    'Display another task' => 'Zu Aufgabe wechseln',
);
